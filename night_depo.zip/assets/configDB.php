<?php

define('DB_HOST', 'db.r3.active24.cz');
define('DB_NAME', 'DB_night_depo');
define('DB_USER', 'DB_nightdepo_user');
define('DB_PASS', 'Pondeli4381+');

define('SMTP_PASS', 'Pondeli4381+');


?>